import React, { useState, useEffect } from 'react';
import { Screen } from './types';
import { getLocalStars, incrementStars, resetStarsToDefault } from './utils/storage';
import { AndroidFrame } from './components/AndroidFrame';
import { HomeScreen } from './components/screens/HomeScreen';
import { HurufScreen } from './components/screens/HurufScreen';
import { AngkaScreen } from './components/screens/AngkaScreen';
import { WarnaScreen } from './components/screens/WarnaScreen';
import { HewanScreen } from './components/screens/HewanScreen';
import { KuisScreen } from './components/screens/KuisScreen';
import { KotlinCodeViewer } from './components/screens/KotlinCodeViewer';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('HOME');
  const [stars, setStars] = useState<number>(5);

  useEffect(() => {
    // Load persisted stars from local storage
    const storedStars = getLocalStars();
    setStars(storedStars);
  }, []);

  const handleAddStar = () => {
    const nextStars = incrementStars(1);
    setStars(nextStars);
  };

  const handleResetStars = () => {
    const zero = resetStarsToDefault();
    setStars(zero);
  };

  const handleNavigate = (screen: Screen) => {
    setCurrentScreen(screen);
    // Scroll to top upon screen navigation
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHome = () => {
    setCurrentScreen('HOME');
  };

  return (
    <AndroidFrame
      currentScreen={currentScreen}
      onOpenKotlin={() => handleNavigate('KOTLIN_CODE')}
    >
      {currentScreen === 'HOME' && (
        <HomeScreen
          stars={stars}
          onNavigate={handleNavigate}
          onResetStars={handleResetStars}
        />
      )}

      {currentScreen === 'HURUF' && (
        <HurufScreen stars={stars} onBack={handleBackToHome} />
      )}

      {currentScreen === 'ANGKA' && (
        <AngkaScreen stars={stars} onBack={handleBackToHome} />
      )}

      {currentScreen === 'WARNA' && (
        <WarnaScreen stars={stars} onBack={handleBackToHome} />
      )}

      {currentScreen === 'HEWAN' && (
        <HewanScreen stars={stars} onBack={handleBackToHome} />
      )}

      {currentScreen === 'KUIS' && (
        <KuisScreen
          stars={stars}
          onAddStar={handleAddStar}
          onBack={handleBackToHome}
        />
      )}

      {currentScreen === 'KOTLIN_CODE' && (
        <KotlinCodeViewer onBack={handleBackToHome} />
      )}
    </AndroidFrame>
  );
}
