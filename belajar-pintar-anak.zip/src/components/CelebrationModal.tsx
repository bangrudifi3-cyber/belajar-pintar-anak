import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, ArrowRight } from 'lucide-react';
import { ChildButton } from './ChildButton';
import { playStarChime } from '../utils/sound';

interface CelebrationModalProps {
  isOpen: boolean;
  praiseText: string;
  isLastQuestion?: boolean;
  onNextQuestion: () => void;
}

export const CelebrationModal: React.FC<CelebrationModalProps> = ({
  isOpen,
  praiseText,
  isLastQuestion = false,
  onNextQuestion,
}) => {
  useEffect(() => {
    if (isOpen) {
      playStarChime();
      // Cheerful kid-friendly burst of confetti
      const count = 100;
      const defaults = {
        origin: { y: 0.6 },
        colors: ['#F59E0B', '#EF4444', '#10B981', '#3B82F6', '#EC4899', '#8B5CF6'],
      };

      confetti({
        ...defaults,
        particleCount: Math.floor(count * 0.7),
        spread: 70,
      });

      const timer = setTimeout(() => {
        confetti({
          ...defaults,
          particleCount: Math.floor(count * 0.5),
          spread: 90,
        });
      }, 180);

      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div
      id="celebration-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        id="celebration-modal-card"
        className="w-full max-w-sm bg-gradient-to-b from-amber-50 to-white rounded-3xl p-6 shadow-2xl border-4 border-yellow-300 text-center relative overflow-hidden transform animate-in zoom-in-95 duration-200"
      >
        {/* Decorative corner stars */}
        <div className="absolute top-2 left-3 text-2xl animate-spin text-amber-400">✨</div>
        <div className="absolute top-2 right-3 text-2xl animate-spin text-amber-400">✨</div>

        {/* Big Jumping Star Badge */}
        <div className="relative inline-block my-2">
          <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-tr from-amber-300 to-yellow-400 flex items-center justify-center shadow-lg border-4 border-white animate-bounce">
            <span className="text-5xl">⭐</span>
          </div>
          <span className="absolute -bottom-1 -right-2 px-2.5 py-0.5 bg-rose-500 text-white font-black text-xs rounded-full shadow-sm">
            +1 BINTANG
          </span>
        </div>

        {/* Big "Hebat!" as requested */}
        <h2 className="text-3xl font-black text-amber-900 tracking-tight mt-2 flex items-center justify-center gap-2">
          <span>Hebat!</span>
          <Sparkles className="w-6 h-6 text-amber-500" />
        </h2>

        <p className="text-base font-bold text-emerald-700 mt-2 bg-emerald-50 py-2 px-3 rounded-2xl border border-emerald-200">
          {praiseText || 'Jawabanmu benar sekali!'}
        </p>

        <p className="text-xs font-semibold text-slate-500 mt-3">
          1 Bintang emas ditambahkan ke koleksimu! ⭐
        </p>

        {/* Action button */}
        <div className="mt-5">
          <ChildButton
            id="celebration-next-button"
            color="emerald"
            size="lg"
            onClick={onNextQuestion}
            className="w-full text-lg shadow-lg"
          >
            <span>{isLastQuestion ? 'Lihat Hasil Kuis' : 'Soal Berikutnya'}</span>
            <ArrowRight className="w-5 h-5 stroke-[3]" />
          </ChildButton>
        </div>
      </div>
    </div>
  );
};
