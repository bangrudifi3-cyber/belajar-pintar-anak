import React from 'react';
import { playPop } from '../utils/sound';

interface ChildButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  color?: 'amber' | 'blue' | 'emerald' | 'rose' | 'purple' | 'orange' | 'cyan' | 'slate';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  disabled?: boolean;
  ariaLabel?: string;
  id?: string;
}

export const ChildButton: React.FC<ChildButtonProps> = ({
  onClick,
  children,
  color = 'amber',
  size = 'md',
  className = '',
  disabled = false,
  ariaLabel,
  id,
}) => {
  const handleClick = (e: React.MouseEvent) => {
    if (disabled) return;
    playPop();
    onClick();
  };

  const colorStyles = {
    amber: 'bg-amber-400 hover:bg-amber-300 text-amber-950 border-b-4 border-amber-600 active:border-b-0 shadow-amber-200',
    blue: 'bg-sky-500 hover:bg-sky-400 text-white border-b-4 border-sky-700 active:border-b-0 shadow-sky-200',
    emerald: 'bg-emerald-500 hover:bg-emerald-400 text-white border-b-4 border-emerald-700 active:border-b-0 shadow-emerald-200',
    rose: 'bg-rose-500 hover:bg-rose-400 text-white border-b-4 border-rose-700 active:border-b-0 shadow-rose-200',
    purple: 'bg-purple-500 hover:bg-purple-400 text-white border-b-4 border-purple-700 active:border-b-0 shadow-purple-200',
    orange: 'bg-orange-500 hover:bg-orange-400 text-white border-b-4 border-orange-700 active:border-b-0 shadow-orange-200',
    cyan: 'bg-cyan-500 hover:bg-cyan-400 text-white border-b-4 border-cyan-700 active:border-b-0 shadow-cyan-200',
    slate: 'bg-slate-200 hover:bg-slate-100 text-slate-700 border-b-4 border-slate-400 active:border-b-0 shadow-slate-200',
  }[color];

  const sizeStyles = {
    sm: 'px-4 py-2 text-sm rounded-xl',
    md: 'px-5 py-3 text-base rounded-2xl min-h-[48px]',
    lg: 'px-6 py-4 text-xl rounded-3xl min-h-[58px]',
    xl: 'px-7 py-5 text-2xl rounded-3xl min-h-[70px]',
  }[size];

  return (
    <button
      id={id}
      type="button"
      disabled={disabled}
      aria-label={ariaLabel}
      onClick={handleClick}
      className={`
        font-bold tracking-wide transition-all duration-100 ease-out
        transform active:translate-y-1 active:shadow-none
        flex items-center justify-center gap-2 cursor-pointer
        disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none disabled:border-b-2
        ${colorStyles}
        ${sizeStyles}
        ${className}
      `}
    >
      {children}
    </button>
  );
};
