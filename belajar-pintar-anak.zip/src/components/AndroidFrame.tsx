import React, { useState } from 'react';
import { Smartphone, Maximize2, Wifi, Battery, Code2 } from 'lucide-react';
import { Screen } from '../types';

interface AndroidFrameProps {
  children: React.ReactNode;
  currentScreen: Screen;
  onOpenKotlin: () => void;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  currentScreen,
  onOpenKotlin,
}) => {
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-0 sm:p-4 selection:bg-amber-300 selection:text-amber-900">
      {/* Top Helper Toolbar (Desktop / Tablet view) */}
      <div className="w-full max-w-md mb-2 px-2 flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 border border-slate-700 rounded-lg text-emerald-400 font-mono font-medium text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            Android Native Simulation
          </span>
          <span className="hidden sm:inline text-slate-400 text-[11px]">
            Portrait • Kotlin & Compose
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {currentScreen !== 'KOTLIN_CODE' && (
            <button
              id="btn-switch-to-kotlin-header"
              type="button"
              onClick={onOpenKotlin}
              className="flex items-center gap-1 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-bold text-[11px] transition-colors shadow-xs"
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Kode Kotlin</span>
            </button>
          )}

          <button
            id="btn-toggle-frame-mode"
            type="button"
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg font-medium text-[11px] transition-colors"
            title={isPhoneFrame ? 'Mode Layar Penuh' : 'Mode HP Android'}
          >
            {isPhoneFrame ? (
              <>
                <Maximize2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Penuh</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">HP Frame</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Container: Phone Frame or Responsive Fullscreen */}
      <div
        className={`
          w-full transition-all duration-300 flex flex-col bg-amber-50
          ${
            isPhoneFrame
              ? 'max-w-[430px] h-[92vh] max-h-[880px] rounded-[44px] shadow-2xl border-[8px] border-slate-800 overflow-hidden relative'
              : 'max-w-2xl min-h-screen sm:min-h-[90vh] sm:rounded-3xl shadow-xl overflow-hidden'
          }
        `}
      >
        {/* Android Status Bar (Shown in Phone Frame Mode) */}
        {isPhoneFrame && (
          <div className="h-7 bg-white/70 backdrop-blur-md px-6 flex items-center justify-between text-[11px] font-bold text-slate-700 select-none shrink-0 z-30 border-b border-amber-100/60">
            <span>09:41</span>

            {/* Android Camera Hole Punch */}
            <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-700 mx-auto" />

            <div className="flex items-center gap-1.5">
              <Wifi className="w-3 h-3 text-slate-600" />
              <Battery className="w-3.5 h-3.5 text-slate-600" />
            </div>
          </div>
        )}

        {/* Dynamic Screen Viewport */}
        <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col">
          {children}
        </div>

        {/* Android Gesture Bar / Home Indicator (Shown in Phone Frame Mode) */}
        {isPhoneFrame && (
          <div className="h-4 bg-white/50 backdrop-blur-xs flex items-center justify-center shrink-0">
            <div className="w-32 h-1 bg-slate-300 rounded-full" />
          </div>
        )}
      </div>
    </div>
  );
};
