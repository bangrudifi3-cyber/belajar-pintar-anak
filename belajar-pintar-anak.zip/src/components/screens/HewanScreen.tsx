import React, { useState } from 'react';
import { Volume2, ChevronLeft, ChevronRight, Music } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopBar } from '../TopBar';
import { ChildButton } from '../ChildButton';
import { HEWAN_DATA } from '../../data/hewanData';
import { speakText, playPop, playAnimalSound } from '../../utils/sound';

interface HewanScreenProps {
  stars: number;
  onBack: () => void;
}

export const HewanScreen: React.FC<HewanScreenProps> = ({ stars, onBack }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const item = HEWAN_DATA[currentIndex];

  // Tombol speaker membacakan nama hewan
  const handleSpeak = () => {
    speakText(`Hewan ${item.nama}`);
  };

  const handlePlaySoundOnly = () => {
    playAnimalSound(item.suaraAudioType);
    speakText(`${item.nama}, ${item.suaraTeks}`);
  };

  const handleNext = () => {
    if (currentIndex < HEWAN_DATA.length - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      const nextItem = HEWAN_DATA[nextIdx];
      playAnimalSound(nextItem.suaraAudioType);
      speakText(`Hewan ${nextItem.nama}`);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      const prevIdx = currentIndex - 1;
      setCurrentIndex(prevIdx);
      const prevItem = HEWAN_DATA[prevIdx];
      playAnimalSound(prevItem.suaraAudioType);
      speakText(`Hewan ${prevItem.nama}`);
    }
  };

  return (
    <div className="min-h-full flex flex-col justify-between bg-gradient-to-b from-amber-50/60 via-white to-orange-50/40">
      {/* Top Bar */}
      <TopBar
        title="Mengenal Hewan"
        subtitle={`Hewan ${item.nama} (${currentIndex + 1} dari ${HEWAN_DATA.length})`}
        stars={stars}
        onBack={onBack}
        onSpeak={handleSpeak}
        bgClass="bg-amber-50/90"
      />

      <div className="flex-1 p-4 flex flex-col justify-between max-w-lg mx-auto w-full">
        {/* Quick animal icon selectors */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar justify-between">
          {HEWAN_DATA.map((h, idx) => (
            <button
              key={h.id}
              type="button"
              onClick={() => {
                playPop();
                setCurrentIndex(idx);
                playAnimalSound(h.suaraAudioType);
                speakText(`Hewan ${h.nama}`);
              }}
              className={`
                w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 text-2xl
                border-2 transition-transform cursor-pointer
                ${
                  idx === currentIndex
                    ? 'bg-amber-400 border-amber-600 shadow-sm scale-110'
                    : 'bg-white border-amber-100 hover:bg-amber-50'
                }
              `}
              title={h.nama}
              aria-label={`Pilih hewan ${h.nama}`}
            >
              {h.emoji}
            </button>
          ))}
        </div>

        {/* Main Educational Card with Motion */}
        <div className="flex-1 flex flex-col justify-center my-2">
          <AnimatePresence mode="wait">
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.92, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: -10 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              id="animal-main-card"
              className="bg-white rounded-3xl p-5 shadow-xl border-4 border-amber-200 text-center flex flex-col items-center justify-between gap-2.5"
            >
              {/* Cute Big Animal Mascot & Sound Badge */}
              <div className="relative my-1">
                <div className="w-32 h-32 rounded-3xl bg-gradient-to-tr from-amber-100 to-yellow-200 flex items-center justify-center text-7xl shadow-md border-3 border-white animate-bounce duration-1000">
                  {item.emoji}
                </div>
                <span className="absolute -bottom-2 inset-x-0 mx-auto w-max px-3 py-1 bg-amber-500 text-white font-black text-xs rounded-full shadow-xs">
                  {item.suaraTeks}
                </span>
              </div>

              {/* Nama Hewan */}
              <div className="mt-1">
                <h2 className="text-3xl font-black text-slate-800 tracking-tight">
                  {item.nama}
                </h2>
                <p className="text-xs font-semibold text-slate-500 mt-0.5">
                  {item.suaraKarakter}
                </p>
              </div>

              {/* Detail Info: Habitat & Makanan */}
              <div className="w-full grid grid-cols-2 gap-2 bg-amber-50/70 p-2.5 rounded-2xl border border-amber-100 text-xs">
                <div className="bg-white p-2 rounded-xl border border-amber-100/50">
                  <span className="text-slate-400 font-bold block text-[10px] uppercase">Tempat Tinggal</span>
                  <span className="font-bold text-slate-700">{item.habitat}</span>
                </div>
                <div className="bg-white p-2 rounded-xl border border-amber-100/50">
                  <span className="text-slate-400 font-bold block text-[10px] uppercase">Makanan</span>
                  <span className="font-bold text-slate-700">{item.makanan}</span>
                </div>
              </div>

              {/* Action Buttons: Speaker (Membacakan Nama Hewan) & Sound (Tiruan Suara) */}
              <div className="w-full space-y-2 mt-1">
                <ChildButton
                  id="btn-speak-animal"
                  color="amber"
                  size="lg"
                  onClick={handleSpeak}
                  className="w-full shadow-md text-lg"
                >
                  <Volume2 className="w-6 h-6 animate-pulse" />
                  <span>Dengarkan Nama: "{item.nama}"</span>
                </ChildButton>

                <button
                  id="btn-animal-sound"
                  type="button"
                  onClick={handlePlaySoundOnly}
                  className="w-full py-2 bg-orange-100 hover:bg-orange-200 text-orange-800 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Music className="w-3.5 h-3.5" />
                  <span>Bunyikan Suara: "{item.suaraTeks}"</span>
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom Big Navigation Controls: Sebelumnya & Berikutnya */}
        <div className="flex items-center gap-3 pt-2">
          <ChildButton
            id="btn-prev-animal"
            color="slate"
            size="lg"
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className="flex-1"
          >
            <ChevronLeft className="w-6 h-6 stroke-[3]" />
            <span>Sebelumnya</span>
          </ChildButton>

          <ChildButton
            id="btn-next-animal"
            color="amber"
            size="lg"
            onClick={handleNext}
            disabled={currentIndex === HEWAN_DATA.length - 1}
            className="flex-1"
          >
            <span>Berikutnya</span>
            <ChevronRight className="w-6 h-6 stroke-[3]" />
          </ChildButton>
        </div>
      </div>
    </div>
  );
};
