import React, { useState } from 'react';
import { Volume2, ChevronLeft, ChevronRight, Grid } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopBar } from '../TopBar';
import { ChildButton } from '../ChildButton';
import { HURUF_DATA } from '../../data/hurufData';
import { speakText, playPop } from '../../utils/sound';

interface HurufScreenProps {
  stars: number;
  onBack: () => void;
}

export const HurufScreen: React.FC<HurufScreenProps> = ({ stars, onBack }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showGrid, setShowGrid] = useState(false);
  const item = HURUF_DATA[currentIndex];

  // Ketika speaker ditekan: "A, Apel"
  const handleSpeak = () => {
    speakText(`${item.huruf}, ${item.kata}`);
  };

  const handleNext = () => {
    if (currentIndex < HURUF_DATA.length - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      const nextItem = HURUF_DATA[nextIdx];
      speakText(`${nextItem.huruf}, ${nextItem.kata}`);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      const prevIdx = currentIndex - 1;
      setCurrentIndex(prevIdx);
      const prevItem = HURUF_DATA[prevIdx];
      speakText(`${prevItem.huruf}, ${prevItem.kata}`);
    }
  };

  const selectLetter = (index: number) => {
    playPop();
    setCurrentIndex(index);
    setShowGrid(false);
    const selected = HURUF_DATA[index];
    speakText(`${selected.huruf}, ${selected.kata}`);
  };

  return (
    <div className="min-h-full flex flex-col justify-between bg-gradient-to-b from-rose-50/60 via-white to-pink-50/40">
      {/* Top Bar */}
      <TopBar
        title="Belajar Huruf"
        subtitle={`Huruf ${item.huruf} (${currentIndex + 1} dari 26)`}
        stars={stars}
        onBack={onBack}
        onSpeak={handleSpeak}
        bgClass="bg-rose-50/90"
      />

      <div className="flex-1 p-4 flex flex-col justify-between max-w-lg mx-auto w-full">
        {/* Quick Grid Selector Toggle */}
        <div className="flex items-center justify-between px-1 mb-2">
          <span className="text-xs font-bold text-slate-500">
            Huruf ke-{currentIndex + 1} ({item.huruf})
          </span>
          <button
            id="btn-toggle-alphabet-grid"
            type="button"
            onClick={() => {
              playPop();
              setShowGrid(!showGrid);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-100 hover:bg-rose-200 text-rose-800 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            <Grid className="w-3.5 h-3.5" />
            <span>{showGrid ? 'Tutup Daftar' : 'Pilih Huruf A-Z'}</span>
          </button>
        </div>

        {/* Modal / Inline Grid of A-Z */}
        {showGrid ? (
          <div className="flex-1 bg-white rounded-3xl p-4 shadow-md border-2 border-rose-100 overflow-y-auto max-h-[440px]">
            <h3 className="text-sm font-bold text-slate-700 text-center mb-3">
              Pilih Huruf Yang Ingin Dipelajari:
            </h3>
            <div className="grid grid-cols-5 gap-2">
              {HURUF_DATA.map((h, idx) => (
                <button
                  key={h.huruf}
                  type="button"
                  onClick={() => selectLetter(idx)}
                  className={`
                    h-12 rounded-2xl font-black text-xl flex flex-col items-center justify-center
                    border-b-3 transition-all cursor-pointer
                    ${
                      idx === currentIndex
                        ? 'bg-rose-500 text-white border-rose-700 shadow-md scale-105'
                        : 'bg-rose-50 text-rose-900 border-rose-200 hover:bg-rose-100'
                    }
                  `}
                >
                  <span>{h.huruf}</span>
                  <span className="text-[10px] leading-none opacity-80">{h.emoji}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          /* Main Giant Educational Card with Simple Transition Animation */
          <div className="flex-1 flex flex-col justify-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={item.huruf}
                initial={{ opacity: 0, scale: 0.92, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.92, y: -10 }}
                transition={{ duration: 0.22, ease: 'easeOut' }}
                id="alphabet-main-card"
                className="bg-white rounded-3xl p-6 shadow-xl border-4 border-rose-200 text-center relative overflow-hidden flex flex-col items-center justify-center gap-2"
              >
                {/* Badge Huruf Kecil & Besar */}
                <div className="absolute top-3 right-4 px-3 py-1 bg-rose-100 text-rose-700 font-extrabold text-sm rounded-full">
                  {item.huruf} {item.huruf.toLowerCase()}
                </div>

                {/* Huruf Sangat Besar */}
                <div
                  className="font-black leading-none drop-shadow-sm select-none"
                  style={{
                    fontSize: 'clamp(5.5rem, 20vw, 7.5rem)',
                    color: item.warna,
                  }}
                >
                  {item.huruf}
                </div>

                {/* Ilustrasi Emoji Besar */}
                <div className="text-7xl my-1 animate-bounce duration-1000">
                  {item.emoji}
                </div>

                {/* Contoh Kata: A — Apel */}
                <div className="space-y-1 mt-1">
                  <div className="text-3xl font-black text-slate-800 tracking-tight">
                    <span>{item.huruf}</span>
                    <span className="mx-2 text-rose-300 font-light">—</span>
                    <span style={{ color: item.warna }}>{item.kata}</span>
                  </div>
                  <p className="text-xs font-semibold text-slate-500 px-4">
                    {item.artinya}
                  </p>
                </div>

                {/* Tombol Speaker: Membacakan "A, Apel" */}
                <div className="mt-4 w-full">
                  <ChildButton
                    id="btn-speak-letter"
                    color="rose"
                    size="lg"
                    onClick={handleSpeak}
                    className="w-full shadow-md text-lg"
                  >
                    <Volume2 className="w-6 h-6 animate-pulse" />
                    <span>Dengarkan: "{item.huruf}, {item.kata}"</span>
                  </ChildButton>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        )}

        {/* Bottom Big Navigation Controls: Sebelumnya & Berikutnya */}
        <div className="flex items-center gap-3 pt-4">
          <ChildButton
            id="btn-prev-letter"
            color="slate"
            size="lg"
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className="flex-1"
          >
            <ChevronLeft className="w-6 h-6 stroke-[3]" />
            <span>Sebelumnya</span>
          </ChildButton>

          <ChildButton
            id="btn-next-letter"
            color="rose"
            size="lg"
            onClick={handleNext}
            disabled={currentIndex === HURUF_DATA.length - 1}
            className="flex-1"
          >
            <span>Berikutnya</span>
            <ChevronRight className="w-6 h-6 stroke-[3]" />
          </ChildButton>
        </div>
      </div>
    </div>
  );
};
