import React, { useState } from 'react';
import { Star, ShieldCheck, Sparkles, Code2, Users, ArrowRight } from 'lucide-react';
import { Screen } from '../../types';
import { speakText, playPop } from '../../utils/sound';
import { ParentModal } from '../ParentModal';

interface HomeScreenProps {
  stars: number;
  onNavigate: (screen: Screen) => void;
  onResetStars: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ stars, onNavigate, onResetStars }) => {
  const [isParentModalOpen, setIsParentModalOpen] = useState(false);

  const handleMascotClick = () => {
    playPop();
    speakText('Halo teman pintar! Selamat datang di Belajar Pintar Anak. Ayo kita bermain dan belajar!');
  };

  const menuItems: {
    id: string;
    screen: Screen;
    title: string;
    subtitle: string;
    badge: string;
    emoji: string;
    bgGradient: string;
    borderShadow: string;
    textColor: string;
    speakNarration: string;
  }[] = [
    {
      id: 'menu-huruf',
      screen: 'HURUF',
      title: 'Belajar Huruf',
      subtitle: 'Mengenal Huruf A - Z & Contoh Kata',
      badge: 'A - Z',
      emoji: '🔤',
      bgGradient: 'from-rose-500 via-pink-500 to-rose-600',
      borderShadow: 'border-b-6 border-rose-700 active:border-b-0 shadow-rose-200',
      textColor: 'text-white',
      speakNarration: 'Belajar Huruf A sampai Z',
    },
    {
      id: 'menu-angka',
      screen: 'ANGKA',
      title: 'Belajar Angka',
      subtitle: 'Mengenal Angka 1 - 10 & Berhitung',
      badge: '1 - 10',
      emoji: '🔢',
      bgGradient: 'from-sky-500 via-blue-500 to-indigo-600',
      borderShadow: 'border-b-6 border-sky-700 active:border-b-0 shadow-sky-200',
      textColor: 'text-white',
      speakNarration: 'Belajar Angka satu sampai sepuluh',
    },
    {
      id: 'menu-warna',
      screen: 'WARNA',
      title: 'Belajar Warna',
      subtitle: 'Mengenal Merah, Kuning, Biru & Lainnya',
      badge: '8 Warna',
      emoji: '🎨',
      bgGradient: 'from-emerald-500 via-teal-500 to-emerald-600',
      borderShadow: 'border-b-6 border-emerald-700 active:border-b-0 shadow-emerald-200',
      textColor: 'text-white',
      speakNarration: 'Belajar Mengenal Warna',
    },
    {
      id: 'menu-hewan',
      screen: 'HEWAN',
      title: 'Mengenal Hewan',
      subtitle: 'Nama & Suara Hewan Lucu',
      badge: '8 Hewan',
      emoji: '🦁',
      bgGradient: 'from-amber-500 via-orange-500 to-amber-600',
      borderShadow: 'border-b-6 border-amber-700 active:border-b-0 shadow-amber-200',
      textColor: 'text-white',
      speakNarration: 'Mengenal Hewan dan Suaranya',
    },
    {
      id: 'menu-kuis',
      screen: 'KUIS',
      title: 'Kuis',
      subtitle: 'Jawab Pertanyaan & Kumpulkan Bintang!',
      badge: '⭐ Dapat Bintang',
      emoji: '🏆',
      bgGradient: 'from-purple-500 via-violet-600 to-fuchsia-600',
      borderShadow: 'border-b-6 border-purple-800 active:border-b-0 shadow-purple-200',
      textColor: 'text-white',
      speakNarration: 'Ayo Bermain Kuis!',
    },
  ];

  return (
    <div className="min-h-full flex flex-col justify-between p-4 bg-gradient-to-b from-amber-50/80 via-white to-orange-50/50">
      <div className="space-y-4">
        {/* Top Header: Kid Safe Pill & Stars Counter */}
        <div className="flex items-center justify-between pt-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-100 text-emerald-800 rounded-full text-xs font-bold border border-emerald-200 shadow-2xs">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Mode Aman Anak</span>
          </div>

          {/* Star Counter Pill on Top */}
          <div
            id="home-star-badge"
            className="flex items-center gap-2 px-4 py-1.5 bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-400 rounded-full shadow-md border-2 border-white transform hover:scale-105 transition-transform"
          >
            <Star className="w-6 h-6 fill-amber-500 text-amber-600 drop-shadow-xs animate-bounce" />
            <div className="flex flex-col text-left leading-none">
              <span className="text-xl font-black text-amber-950">{stars}</span>
              <span className="text-[10px] font-extrabold text-amber-900/80 uppercase tracking-wider">Bintang</span>
            </div>
          </div>
        </div>

        {/* Mascot & Main Greeting Title */}
        <div className="text-center pt-0.5 pb-1">
          <button
            id="mascot-avatar"
            type="button"
            onClick={handleMascotClick}
            className="relative inline-block cursor-pointer group active:scale-95 transition-transform"
            aria-label="Ketuk maskot untuk mendengar sapaan"
          >
            <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-amber-200 to-orange-200 flex items-center justify-center text-5xl shadow-md border-3 border-white group-hover:rotate-6 transition-transform">
              🐥
            </div>
            <span className="absolute -bottom-1 -right-2 px-2 py-0.5 bg-amber-500 text-white font-extrabold text-[11px] rounded-full shadow-xs flex items-center gap-1">
              <span>Halo!</span>
              <Sparkles className="w-3 h-3" />
            </span>
          </button>

          <h1 className="text-3xl font-black text-slate-800 tracking-tight mt-2 flex items-center justify-center gap-2">
            <span>Belajar Pintar Anak</span>
          </h1>
          <p className="text-xs font-bold text-slate-500 mt-0.5">
            Edukasi Ceria & Interaktif untuk Usia 4–8 Tahun
          </p>
        </div>

        {/* Big Menu Cards: Huruf, Angka, Warna, Hewan, Kuis */}
        <div className="space-y-3 pt-0.5">
          {menuItems.map((item) => (
            <button
              key={item.id}
              id={item.id}
              type="button"
              onClick={() => {
                playPop();
                speakText(item.speakNarration);
                onNavigate(item.screen);
              }}
              className={`
                w-full p-4 rounded-3xl bg-gradient-to-r ${item.bgGradient} ${item.textColor}
                ${item.borderShadow} flex items-center justify-between text-left
                transform active:translate-y-1 transition-all duration-100 shadow-md cursor-pointer
              `}
            >
              <div className="flex items-center gap-3.5">
                <div className="w-14 h-14 rounded-2xl bg-white/25 backdrop-blur-xs flex items-center justify-center text-3xl shadow-inner shrink-0">
                  {item.emoji}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-black tracking-tight">{item.title}</h2>
                    <span className="text-[10px] font-black bg-white/30 px-2 py-0.5 rounded-full uppercase">
                      {item.badge}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-white/95 mt-0.5">{item.subtitle}</p>
                </div>
              </div>

              <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-white shrink-0">
                <ArrowRight className="w-5 h-5 stroke-[3]" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Footer Section: "Tentang Orang Tua" & Kotlin Code button */}
      <div className="pt-6 pb-2 space-y-2.5">
        {/* Tombol "Tentang Orang Tua" kecil di bagian bawah */}
        <div className="flex items-center justify-center gap-2">
          <button
            id="btn-open-parent-modal"
            type="button"
            onClick={() => {
              playPop();
              setIsParentModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold transition-colors cursor-pointer border border-slate-200"
          >
            <Users className="w-3.5 h-3.5 text-slate-500" />
            <span>Tentang Orang Tua</span>
          </button>
        </div>

        {/* View Native Android Source Code Button */}
        <button
          id="btn-open-kotlin-code"
          type="button"
          onClick={() => {
            playPop();
            onNavigate('KOTLIN_CODE');
          }}
          className="w-full py-2 px-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] flex items-center justify-center gap-2 shadow-2xs transition-all cursor-pointer"
        >
          <Code2 className="w-3.5 h-3.5 text-sky-400" />
          <span>Lihat Kode Native Android (Kotlin & Jetpack Compose)</span>
        </button>

        <div className="text-center text-[10px] text-slate-400 font-medium">
          Aplikasi 100% Bebas Iklan • Tanpa Data Pribadi • Offline
        </div>
      </div>

      {/* Parent Information Modal */}
      <ParentModal
        isOpen={isParentModalOpen}
        onClose={() => setIsParentModalOpen(false)}
        onResetStars={onResetStars}
      />
    </div>
  );
};
