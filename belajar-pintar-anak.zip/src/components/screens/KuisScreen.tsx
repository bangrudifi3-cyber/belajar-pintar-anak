import React, { useState, useEffect, useCallback } from 'react';
import { Volume2, Sparkles, RefreshCw, Smile, Trophy, Star, ArrowLeft, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopBar } from '../TopBar';
import { ChildButton } from '../ChildButton';
import { CelebrationModal } from '../CelebrationModal';
import { KUIS_QUESTIONS } from '../../data/kuisData';
import { QuizQuestion, QuizOption } from '../../types';
import { speakText, playSuccess, playTryAgain, playPop } from '../../utils/sound';

interface KuisScreenProps {
  stars: number;
  onAddStar: () => void;
  onBack: () => void;
}

const QUIZ_SESSION_LENGTH = 10;

// Helper to shuffle array and take N items
function getRandomQuestions(count: number = QUIZ_SESSION_LENGTH): QuizQuestion[] {
  const shuffled = [...KUIS_QUESTIONS].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

export const KuisScreen: React.FC<KuisScreenProps> = ({ stars, onAddStar, onBack }) => {
  const [questions, setQuestions] = useState<QuizQuestion[]>(() => getRandomQuestions(QUIZ_SESSION_LENGTH));
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isCelebrationOpen, setIsCelebrationOpen] = useState(false);
  const [showTryAgain, setShowTryAgain] = useState(false);
  const [wrongTappedIds, setWrongTappedIds] = useState<string[]>([]);
  const [correctFirstTryCount, setCorrectFirstTryCount] = useState(0);
  const [sessionStarsEarned, setSessionStarsEarned] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);

  const currentQ = questions[currentIndex] || questions[0];

  // Function to initialize or restart the quiz
  const handleRestartQuiz = useCallback(() => {
    playPop();
    const newQuestions = getRandomQuestions(QUIZ_SESSION_LENGTH);
    setQuestions(newQuestions);
    setCurrentIndex(0);
    setIsCelebrationOpen(false);
    setShowTryAgain(false);
    setWrongTappedIds([]);
    setCorrectFirstTryCount(0);
    setSessionStarsEarned(0);
    setIsCompleted(false);

    if (newQuestions[0]) {
      speakText(newQuestions[0].suaraTeks);
    }
  }, []);

  // Speak question whenever question changes
  useEffect(() => {
    if (!isCompleted && currentQ) {
      setShowTryAgain(false);
      setWrongTappedIds([]);
      speakText(currentQ.suaraTeks);
    }
  }, [currentIndex, isCompleted, currentQ]);

  const handleSpeakQuestion = () => {
    if (currentQ) {
      speakText(currentQ.suaraTeks);
    }
  };

  const handleSelectOption = (option: QuizOption) => {
    if (!currentQ) return;

    if (option.id === currentQ.jawabanBenarId) {
      // JAWABAN BENAR:
      playSuccess();
      speakText(`Hebat! ${currentQ.pujian}`);

      // Track if answered on first attempt
      if (wrongTappedIds.length === 0) {
        setCorrectFirstTryCount((prev) => prev + 1);
      }

      onAddStar();
      setSessionStarsEarned((prev) => prev + 1);
      setShowTryAgain(false);
      setIsCelebrationOpen(true);
    } else {
      // JAWABAN SALAH:
      // Tampilkan "Coba lagi!", jangan mengurangi bintang
      playTryAgain();
      speakText('Coba lagi!');
      setShowTryAgain(true);

      if (!wrongTappedIds.includes(option.id)) {
        setWrongTappedIds((prev) => [...prev, option.id]);
      }
    }
  };

  const handleProceedAfterCelebration = () => {
    setIsCelebrationOpen(false);
    playPop();

    if (currentIndex + 1 < questions.length) {
      // Lanjut ke soal berikutnya
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Kuis selesai
      setIsCompleted(true);
      speakText('Hore! Kuis telah selesai. Kamu anak yang sangat pintar!');
    }
  };

  // SCREEN: KUIS SELESAI
  if (isCompleted) {
    return (
      <div className="min-h-full flex flex-col justify-between bg-gradient-to-b from-purple-50/70 via-white to-amber-50/50 p-4">
        {/* Top Header */}
        <TopBar
          title="Hasil Kuis Pintar"
          subtitle="Sesi Kuis Selesai!"
          stars={stars}
          onBack={onBack}
          bgClass="bg-purple-50/90"
        />

        <div className="flex-1 flex flex-col justify-center items-center max-w-md mx-auto w-full my-4">
          <div
            id="quiz-completion-card"
            className="w-full bg-white rounded-3xl p-6 shadow-2xl border-4 border-purple-200 text-center relative overflow-hidden"
          >
            {/* Big Trophy Icon */}
            <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-tr from-amber-300 via-yellow-400 to-amber-500 flex items-center justify-center text-5xl shadow-lg border-4 border-white animate-bounce">
              🏆
            </div>

            <h2 className="text-3xl font-black text-slate-800 tracking-tight mt-3">
              Kuis Selesai! Horeee!
            </h2>
            <p className="text-xs font-bold text-slate-500 mt-1">
              Kamu telah menyelesaikan 10 pertanyaan kuis pintar!
            </p>

            {/* Score & Stars Statistics */}
            <div className="mt-5 space-y-3">
              {/* Jumlah Jawaban Benar Langsung */}
              <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-center justify-between">
                <div className="text-left">
                  <span className="text-[11px] font-bold text-emerald-800 uppercase block">
                    Jawaban Benar
                  </span>
                  <span className="text-xs font-semibold text-emerald-700">
                    Pada percobaan pertama
                  </span>
                </div>
                <span className="text-2xl font-black text-emerald-800">
                  {correctFirstTryCount} / {questions.length}
                </span>
              </div>

              {/* Bintang yang Diperoleh di Sesi Ini */}
              <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 flex items-center justify-between">
                <div className="text-left">
                  <span className="text-[11px] font-bold text-amber-900 uppercase block">
                    Bintang Diperoleh
                  </span>
                  <span className="text-xs font-semibold text-amber-800">
                    Hasil dari bermain kuis ini
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-2xl font-black text-amber-950">
                  <span>+{sessionStarsEarned}</span>
                  <Star className="w-6 h-6 fill-amber-500 text-amber-600 animate-spin" />
                </div>
              </div>

              {/* Total Semua Bintang Tersimpan */}
              <div className="p-3.5 bg-purple-50 rounded-2xl border border-purple-200 flex items-center justify-between">
                <div className="text-left">
                  <span className="text-[11px] font-bold text-purple-900 uppercase block">
                    Total Bintang Kamu
                  </span>
                  <span className="text-xs font-semibold text-purple-700">
                    Tersimpan di memori perangkat
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-2xl font-black text-purple-950">
                  <span>{stars}</span>
                  <span className="text-xl">⭐</span>
                </div>
              </div>
            </div>

            {/* Action Buttons: "Main Lagi" & "Kembali ke Beranda" */}
            <div className="mt-6 space-y-3">
              <ChildButton
                id="btn-quiz-play-again"
                color="purple"
                size="lg"
                onClick={handleRestartQuiz}
                className="w-full text-lg shadow-md"
              >
                <RotateCcw className="w-5 h-5 stroke-[3]" />
                <span>Main Lagi (10 Soal Baru)</span>
              </ChildButton>

              <button
                id="btn-quiz-back-home"
                type="button"
                onClick={() => {
                  playPop();
                  onBack();
                }}
                className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm rounded-2xl flex items-center justify-center gap-2 transition-colors cursor-pointer border border-slate-200"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Kembali ke Beranda</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // SCREEN: KUIS SEDANG BERJALAN
  return (
    <div className="min-h-full flex flex-col justify-between bg-gradient-to-b from-purple-50/70 via-white to-amber-50/50">
      {/* Top Bar with Star Counter */}
      <TopBar
        title="Kuis"
        subtitle={`Soal ${currentIndex + 1} dari ${questions.length}`}
        stars={stars}
        onBack={onBack}
        onSpeak={handleSpeakQuestion}
        bgClass="bg-purple-50/90"
      />

      <div className="flex-1 p-4 flex flex-col justify-between max-w-lg mx-auto w-full">
        {/* Question Card with Motion */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQ.id}
            initial={{ opacity: 0, scale: 0.94, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: -8 }}
            transition={{ duration: 0.2 }}
            id="quiz-question-card"
            className="bg-white rounded-3xl p-5 shadow-lg border-4 border-purple-200 text-center relative overflow-hidden"
          >
            {/* Category Badge & Question Progress */}
            <div className="flex items-center justify-between mb-3 px-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-100 text-purple-700 font-extrabold text-xs rounded-full">
                <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                <span>Kuis {currentQ.kategori}</span>
              </div>

              <span className="text-xs font-black text-purple-600 bg-purple-50 px-2.5 py-1 rounded-full border border-purple-100">
                {currentIndex + 1} / {questions.length}
              </span>
            </div>

            {/* Pertanyaan Besar */}
            <h2 className="text-2xl sm:text-3xl font-black text-slate-800 tracking-tight leading-snug px-1">
              {currentQ.pertanyaan}
            </h2>

            {/* Tombol Speaker Soal */}
            <div className="mt-3 flex justify-center">
              <button
                id="btn-speak-quiz-question"
                type="button"
                onClick={handleSpeakQuestion}
                className="flex items-center gap-2 px-4 py-2 bg-purple-100 hover:bg-purple-200 text-purple-800 rounded-2xl text-xs font-bold transition-all shadow-2xs active:scale-95 cursor-pointer"
              >
                <Volume2 className="w-4 h-4" />
                <span>Dengarkan Soal</span>
              </button>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Soft Feedback Banner: "Coba lagi!" (tanpa pengurangan bintang) */}
        {showTryAgain && (
          <div
            id="quiz-try-again-banner"
            className="my-3 p-3.5 bg-amber-50 rounded-2xl border-2 border-amber-300 text-amber-900 flex items-center gap-2.5 animate-in slide-in-from-top-2 duration-200"
          >
            <Smile className="w-6 h-6 text-amber-500 shrink-0 animate-bounce" />
            <div className="text-left">
              <span className="text-sm font-black block">Coba lagi!</span>
              <span className="text-xs font-semibold text-amber-800">
                Pilih jawaban lain, kamu pasti bisa! ⭐
              </span>
            </div>
          </div>
        )}

        {/* Pilihan Jawaban (3 atau 4 tombol kartu besar) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-3">
          {currentQ.pilihan.map((option) => {
            const isWrong = wrongTappedIds.includes(option.id);
            return (
              <button
                key={option.id}
                id={`quiz-option-${option.id}`}
                type="button"
                onClick={() => handleSelectOption(option)}
                className={`
                  p-4 rounded-3xl border-b-5 text-left flex items-center gap-3.5
                  transform active:translate-y-1 transition-all duration-100 cursor-pointer
                  shadow-md min-h-[76px]
                  ${
                    isWrong
                      ? 'bg-amber-50/70 border-amber-300 text-amber-900/60 opacity-60'
                      : 'bg-white hover:bg-purple-50/50 border-purple-300 active:border-b-0 text-slate-800'
                  }
                `}
              >
                {/* Visual Circle / Color / Emoji */}
                <div
                  style={option.isColor && option.colorHex ? { backgroundColor: option.colorHex } : undefined}
                  className={`
                    w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shrink-0
                    ${option.isColor ? 'border-2 border-white shadow-xs' : 'bg-purple-50'}
                  `}
                >
                  {option.isColor ? null : option.visual}
                </div>

                <div className="flex-1">
                  <div className="text-xl font-black tracking-tight leading-tight">
                    {option.label}
                  </div>
                  {option.subLabel && (
                    <div className="text-xs font-semibold text-slate-500 mt-0.5">
                      {option.subLabel}
                    </div>
                  )}
                </div>

                <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-700 font-bold text-sm">
                  👉
                </div>
              </button>
            );
          })}
        </div>

        {/* Bottom Helper Controls */}
        <div className="flex items-center justify-between pt-1">
          <div className="text-xs font-bold text-amber-700 flex items-center gap-1">
            <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
            <span>Jawaban benar: +1 Bintang!</span>
          </div>

          <button
            id="btn-skip-question"
            type="button"
            onClick={() => {
              playPop();
              if (currentIndex + 1 < questions.length) {
                setCurrentIndex((prev) => prev + 1);
              } else {
                handleRestartQuiz();
              }
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-purple-600 hover:text-purple-700 py-1.5 px-3 rounded-xl hover:bg-purple-50 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Ganti Soal</span>
          </button>
        </div>
      </div>

      {/* Celebration Popup when correct: "Hebat!" */}
      <CelebrationModal
        isOpen={isCelebrationOpen}
        praiseText={currentQ.pujian}
        isLastQuestion={currentIndex + 1 >= questions.length}
        onNextQuestion={handleProceedAfterCelebration}
      />
    </div>
  );
};
