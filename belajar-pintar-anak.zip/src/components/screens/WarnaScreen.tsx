import React, { useState } from 'react';
import { Volume2, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopBar } from '../TopBar';
import { ChildButton } from '../ChildButton';
import { WARNA_DATA } from '../../data/warnaData';
import { speakText, playPop } from '../../utils/sound';

interface WarnaScreenProps {
  stars: number;
  onBack: () => void;
}

export const WarnaScreen: React.FC<WarnaScreenProps> = ({ stars, onBack }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const item = WARNA_DATA[currentIndex];

  // Tombol speaker membacakan nama warna
  const handleSpeak = () => {
    speakText(`Warna ${item.nama}`);
  };

  const handleNext = () => {
    if (currentIndex < WARNA_DATA.length - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      const nextItem = WARNA_DATA[nextIdx];
      speakText(`Warna ${nextItem.nama}`);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      const prevIdx = currentIndex - 1;
      setCurrentIndex(prevIdx);
      const prevItem = WARNA_DATA[prevIdx];
      speakText(`Warna ${prevItem.nama}`);
    }
  };

  return (
    <div className="min-h-full flex flex-col justify-between bg-gradient-to-b from-emerald-50/60 via-white to-teal-50/40">
      {/* Top Bar */}
      <TopBar
        title="Belajar Warna"
        subtitle={`Warna ${item.nama} (${currentIndex + 1} dari ${WARNA_DATA.length})`}
        stars={stars}
        onBack={onBack}
        onSpeak={handleSpeak}
        bgClass="bg-emerald-50/90"
      />

      <div className="flex-1 p-4 flex flex-col justify-between max-w-lg mx-auto w-full">
        {/* Color Palette Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar justify-between">
          {WARNA_DATA.map((w, idx) => (
            <button
              key={w.id}
              type="button"
              onClick={() => {
                playPop();
                setCurrentIndex(idx);
                speakText(`Warna ${w.nama}`);
              }}
              style={{ backgroundColor: w.hex }}
              className={`
                w-9 h-9 rounded-full shrink-0 shadow-xs border-3 transition-transform cursor-pointer
                ${
                  idx === currentIndex
                    ? 'border-slate-800 scale-125 shadow-md'
                    : 'border-white hover:scale-110'
                }
              `}
              title={w.nama}
              aria-label={`Pilih warna ${w.nama}`}
            />
          ))}
        </div>

        {/* Main Educational Card with Motion */}
        <div className="flex-1 flex flex-col justify-center my-2">
          <AnimatePresence mode="wait">
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.92, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: -10 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              id="color-main-card"
              className="bg-white rounded-3xl p-5 shadow-xl border-4 border-emerald-200 text-center flex flex-col items-center justify-between gap-3"
            >
              {/* Big Vibrant Color Circle */}
              <div className="relative my-1">
                <div
                  style={{ backgroundColor: item.hex }}
                  className="w-32 h-32 rounded-full mx-auto shadow-inner border-4 border-white flex items-center justify-center transition-all duration-300 transform hover:scale-105"
                >
                  <Sparkles className={`w-12 h-12 ${item.id === 'putih' ? 'text-slate-400' : 'text-white/85'} drop-shadow-xs`} />
                </div>
              </div>

              {/* Nama Warna */}
              <div>
                <h2
                  style={{ color: item.id === 'putih' ? '#475569' : item.hex }}
                  className="text-4xl font-black tracking-tight drop-shadow-2xs"
                >
                  {item.nama}
                </h2>
                <p className="text-xs font-semibold text-slate-500 mt-1 max-w-xs mx-auto">
                  {item.deskripsi}
                </p>
              </div>

              {/* Contoh Benda Nyata Sederhana */}
              <div className="w-full bg-slate-50/80 rounded-2xl p-3 border border-slate-100">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  Contoh Objek Berwarna {item.nama}:
                </span>
                <div className="grid grid-cols-4 gap-2">
                  {item.contohBenda.map((benda) => (
                    <button
                      key={benda.nama}
                      type="button"
                      onClick={() => {
                        playPop();
                        speakText(`${benda.nama} berwarna ${item.nama}`);
                      }}
                      className="p-2 bg-white rounded-xl shadow-2xs border border-slate-100 flex flex-col items-center justify-center hover:scale-105 active:scale-95 transition-transform cursor-pointer"
                    >
                      <span className="text-3xl">{benda.emoji}</span>
                      <span className="text-[11px] font-bold text-slate-700 mt-1 truncate w-full text-center">
                        {benda.nama}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Tombol Speaker: Membacakan Nama Warna */}
              <div className="w-full">
                <ChildButton
                  id="btn-speak-color"
                  color="emerald"
                  size="lg"
                  onClick={handleSpeak}
                  className="w-full shadow-md text-lg"
                >
                  <Volume2 className="w-6 h-6 animate-pulse" />
                  <span>Dengarkan Warna: "{item.nama}"</span>
                </ChildButton>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom Big Navigation Controls: Sebelumnya & Berikutnya */}
        <div className="flex items-center gap-3 pt-2">
          <ChildButton
            id="btn-prev-color"
            color="slate"
            size="lg"
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className="flex-1"
          >
            <ChevronLeft className="w-6 h-6 stroke-[3]" />
            <span>Sebelumnya</span>
          </ChildButton>

          <ChildButton
            id="btn-next-color"
            color="emerald"
            size="lg"
            onClick={handleNext}
            disabled={currentIndex === WARNA_DATA.length - 1}
            className="flex-1"
          >
            <span>Berikutnya</span>
            <ChevronRight className="w-6 h-6 stroke-[3]" />
          </ChildButton>
        </div>
      </div>
    </div>
  );
};
