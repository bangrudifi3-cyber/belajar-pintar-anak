import React, { useState } from 'react';
import { Volume2, ChevronLeft, ChevronRight, Hand } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopBar } from '../TopBar';
import { ChildButton } from '../ChildButton';
import { ANGKA_DATA } from '../../data/angkaData';
import { speakText, playPop, playTapTone } from '../../utils/sound';

interface AngkaScreenProps {
  stars: number;
  onBack: () => void;
}

export const AngkaScreen: React.FC<AngkaScreenProps> = ({ stars, onBack }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [tappedIndexes, setTappedIndexes] = useState<number[]>([]);
  const item = ANGKA_DATA[currentIndex];

  const handleSpeak = () => {
    speakText(`Angka ${item.angka}, ${item.terbilang}. Ada ${item.angka} ${item.objekNama}.`);
  };

  const handleNext = () => {
    if (currentIndex < ANGKA_DATA.length - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      setTappedIndexes([]);
      const nextItem = ANGKA_DATA[nextIdx];
      speakText(`Angka ${nextItem.angka}, ${nextItem.terbilang}`);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      const prevIdx = currentIndex - 1;
      setCurrentIndex(prevIdx);
      setTappedIndexes([]);
      const prevItem = ANGKA_DATA[prevIdx];
      speakText(`Angka ${prevItem.angka}, ${prevItem.terbilang}`);
    }
  };

  const handleTapObject = (objIndex: number) => {
    playTapTone(objIndex + 1);
    if (!tappedIndexes.includes(objIndex)) {
      setTappedIndexes([...tappedIndexes, objIndex]);
    }
    speakText(`${objIndex + 1}`);
  };

  return (
    <div className="min-h-full flex flex-col justify-between bg-gradient-to-b from-sky-50/60 via-white to-blue-50/40">
      {/* Top Bar */}
      <TopBar
        title="Belajar Angka"
        subtitle={`Angka ${item.angka} (${item.terbilang})`}
        stars={stars}
        onBack={onBack}
        onSpeak={handleSpeak}
        bgClass="bg-sky-50/90"
      />

      <div className="flex-1 p-4 flex flex-col justify-between max-w-lg mx-auto w-full">
        {/* Quick horizontal selector 1 - 10 */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar justify-between">
          {ANGKA_DATA.map((a, idx) => (
            <button
              key={a.angka}
              type="button"
              onClick={() => {
                playPop();
                setCurrentIndex(idx);
                setTappedIndexes([]);
                speakText(`Angka ${a.angka}, ${a.terbilang}`);
              }}
              className={`
                w-9 h-9 rounded-xl font-black text-sm flex items-center justify-center shrink-0
                border-b-2 transition-all cursor-pointer
                ${
                  idx === currentIndex
                    ? 'bg-sky-500 text-white border-sky-700 shadow-sm scale-110'
                    : 'bg-sky-100/70 text-sky-900 border-sky-200 hover:bg-sky-200'
                }
              `}
            >
              {a.angka}
            </button>
          ))}
        </div>

        {/* Main Educational Card with Motion Transition */}
        <div className="flex-1 flex flex-col justify-center my-2">
          <AnimatePresence mode="wait">
            <motion.div
              key={item.angka}
              initial={{ opacity: 0, scale: 0.92, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: -10 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              id="number-main-card"
              className="bg-white rounded-3xl p-5 shadow-xl border-4 border-sky-200 text-center flex flex-col items-center justify-between gap-3"
            >
              {/* Header Angka Sangat Besar & Terbilang */}
              <div>
                <div
                  className="font-black leading-none drop-shadow-sm select-none"
                  style={{
                    fontSize: 'clamp(5rem, 18vw, 6.5rem)',
                    color: item.warna,
                  }}
                >
                  {item.angka}
                </div>
                <div className="text-3xl font-black text-slate-800 tracking-tight mt-1">
                  {item.terbilang}
                </div>
                <p className="text-xs font-bold text-sky-600 mt-0.5">
                  {item.objekNama}
                </p>
              </div>

              {/* Interactive Countable Object Container */}
              <div className="w-full bg-sky-50/70 rounded-2xl p-3.5 border border-sky-100">
                <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-slate-500 mb-2">
                  <Hand className="w-3.5 h-3.5 text-sky-500" />
                  <span>Ada {item.angka} objek! Ketuk untuk berhitung:</span>
                </div>

                {/* Grid of interactive emoji objects (exact count as item.angka) */}
                <div className="flex flex-wrap items-center justify-center gap-2.5 max-h-[160px] overflow-y-auto p-1">
                  {item.listObjek.map((emoji, objIdx) => {
                    const isTapped = tappedIndexes.includes(objIdx);
                    return (
                      <button
                        key={objIdx}
                        type="button"
                        onClick={() => handleTapObject(objIdx)}
                        className={`
                          w-12 h-12 rounded-2xl flex flex-col items-center justify-center text-3xl
                          cursor-pointer transition-all duration-150 relative
                          ${
                            isTapped
                              ? 'bg-amber-100 border-2 border-amber-400 scale-110 shadow-sm'
                              : 'bg-white border-2 border-sky-100 hover:scale-105 shadow-2xs'
                          }
                        `}
                      >
                        <span>{emoji}</span>
                        {isTapped && (
                          <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-amber-500 text-white text-[10px] font-black flex items-center justify-center shadow-xs">
                            {objIdx + 1}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Tombol Speaker */}
              <div className="w-full">
                <ChildButton
                  id="btn-speak-number"
                  color="sky"
                  size="lg"
                  onClick={handleSpeak}
                  className="w-full shadow-md text-lg"
                >
                  <Volume2 className="w-6 h-6 animate-pulse" />
                  <span>Dengarkan Angka {item.angka}</span>
                </ChildButton>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom Big Navigation Controls: Sebelumnya & Berikutnya */}
        <div className="flex items-center gap-3 pt-2">
          <ChildButton
            id="btn-prev-number"
            color="slate"
            size="lg"
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className="flex-1"
          >
            <ChevronLeft className="w-6 h-6 stroke-[3]" />
            <span>Sebelumnya</span>
          </ChildButton>

          <ChildButton
            id="btn-next-number"
            color="sky"
            size="lg"
            onClick={handleNext}
            disabled={currentIndex === ANGKA_DATA.length - 1}
            className="flex-1"
          >
            <span>Berikutnya</span>
            <ChevronRight className="w-6 h-6 stroke-[3]" />
          </ChildButton>
        </div>
      </div>
    </div>
  );
};
