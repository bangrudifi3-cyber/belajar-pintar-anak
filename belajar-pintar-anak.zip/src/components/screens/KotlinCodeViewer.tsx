import React, { useState } from 'react';
import { Copy, Check, ArrowLeft, Download, FileCode, Terminal, Sparkles, Folder } from 'lucide-react';
import { KOTLIN_PROJECT_FILES, KotlinFile } from '../../data/kotlinProjectData';
import { playPop } from '../../utils/sound';

interface KotlinCodeViewerProps {
  onBack: () => void;
}

export const KotlinCodeViewer: React.FC<KotlinCodeViewerProps> = ({ onBack }) => {
  const [selectedFile, setSelectedFile] = useState<KotlinFile>(KOTLIN_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    playPop();
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadAll = () => {
    playPop();
    const combinedContent = KOTLIN_PROJECT_FILES.map(
      (f) => `// ==========================================\n// FILE: ${f.path}\n// ${f.description}\n// ==========================================\n\n${f.code}\n\n`
    ).join('\n');

    const blob = new Blob([combinedContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'BelajarPintarAnak_Kotlin_JetpackCompose.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-full flex flex-col bg-slate-900 text-slate-100">
      {/* Top Header */}
      <header className="px-4 py-3 bg-slate-800/90 border-b border-slate-700 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <button
            id="btn-back-to-app"
            type="button"
            onClick={() => {
              playPop();
              onBack();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali ke Aplikasi</span>
          </button>

          <div className="flex items-center gap-1.5">
            <span className="text-xl">🤖</span>
            <div>
              <h1 className="text-sm font-bold text-white leading-none">
                Source Code Android (Kotlin & Jetpack Compose)
              </h1>
              <span className="text-[11px] text-emerald-400 font-mono">
                Belajar Pintar Anak Native App
              </span>
            </div>
          </div>
        </div>

        <button
          id="btn-download-all-kotlin"
          type="button"
          onClick={handleDownloadAll}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Ekspor Proyek</span>
        </button>
      </header>

      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Sidebar / File List */}
        <aside className="w-full md:w-64 bg-slate-850 border-r border-slate-800 p-3 overflow-y-auto shrink-0">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-2">
            <Folder className="w-3.5 h-3.5 text-amber-400" />
            <span>Berkas Proyek Kotlin</span>
          </div>

          <div className="space-y-1">
            {KOTLIN_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.name === file.name;
              return (
                <button
                  key={file.name}
                  type="button"
                  onClick={() => {
                    playPop();
                    setSelectedFile(file);
                  }}
                  className={`
                    w-full text-left px-3 py-2 rounded-xl text-xs font-mono flex items-center justify-between
                    transition-colors cursor-pointer
                    ${
                      isSelected
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }
                  `}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className={`w-3.5 h-3.5 ${isSelected ? 'text-sky-400' : 'text-slate-500'}`} />
                    <span className="truncate">{file.name}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Android Highlights Box */}
          <div className="mt-4 p-3 bg-slate-800/80 rounded-2xl border border-slate-700/60 text-[11px] space-y-1.5">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Spesifikasi Native:</span>
            </div>
            <ul className="text-slate-300 space-y-1 list-disc list-inside">
              <li>Kotlin 2.0 & Jetpack Compose BOM</li>
              <li>Material 3 Child Friendly Design</li>
              <li>Locked Portrait Orientation</li>
              <li>Offline DataStore Star Persistence</li>
              <li>Android TextToSpeech (`id-ID`)</li>
              <li>Tanpa Login & Tanpa Iklan</li>
            </ul>
          </div>
        </aside>

        {/* Main Code Preview Pane */}
        <main className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
          {/* File Header */}
          <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 truncate">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-mono text-slate-300 font-semibold truncate">
                {selectedFile.path}
              </span>
              <span className="hidden sm:inline text-[11px] text-slate-500">
                — {selectedFile.description}
              </span>
            </div>

            <button
              id="btn-copy-code"
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-bold">Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin Kode</span>
                </>
              )}
            </button>
          </div>

          {/* Code Viewer Container */}
          <div className="flex-1 p-4 overflow-auto font-mono text-xs text-slate-200 leading-relaxed select-text">
            <pre className="whitespace-pre">
              <code>{selectedFile.code}</code>
            </pre>
          </div>
        </main>
      </div>
    </div>
  );
};
