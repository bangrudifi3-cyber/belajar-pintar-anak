import React, { useState } from 'react';
import { ShieldCheck, Heart, Sparkles, X, RotateCcw, CheckCircle2, Lock } from 'lucide-react';
import { ChildButton } from './ChildButton';
import { playPop } from '../utils/sound';

interface ParentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onResetStars: () => void;
}

export const ParentModal: React.FC<ParentModalProps> = ({
  isOpen,
  onClose,
  onResetStars,
}) => {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [mathAnswer, setMathAnswer] = useState('');
  const [mathError, setMathError] = useState(false);

  if (!isOpen) return null;

  const handleConfirmReset = () => {
    // Simple parental challenge: 4 + 3 = 7
    if (mathAnswer.trim() === '7') {
      playPop();
      onResetStars();
      setShowResetConfirm(false);
      setMathAnswer('');
      setMathError(false);
    } else {
      setMathError(true);
    }
  };

  return (
    <div
      id="parent-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150"
    >
      <div
        id="parent-modal-card"
        className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border-4 border-emerald-200 text-left relative max-h-[90vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={() => {
            playPop();
            onClose();
          }}
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
          aria-label="Tutup"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-2 mb-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-700">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-800 leading-tight">
              Tentang Orang Tua
            </h2>
            <p className="text-xs text-slate-500">Panduan & Keamanan Aplikasi</p>
          </div>
        </div>

        <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
          {/* Security Features */}
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-100 space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-emerald-900 text-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Jaminan Privasi & Ramah Anak</span>
            </div>
            <ul className="space-y-1 text-emerald-800 list-disc list-inside">
              <li><strong>100% Tanpa Iklan:</strong> Bebas dari gangguan iklan komersial.</li>
              <li><strong>Tanpa Pengumpulan Data:</strong> Tidak meminta email, nama, lokasi, nomor telepon, atau data pribadi anak.</li>
              <li><strong>Bekerja Offline:</strong> Seluruh modul huruf, angka, warna, hewan, dan kuis berjalan langsung di memori perangkat tanpa server.</li>
              <li><strong>Tanpa Pembelian Tersembunyi:</strong> Semua konten pembelajaran terbuka penuh.</li>
            </ul>
          </div>

          {/* Educational Philosophy */}
          <div className="p-3 bg-amber-50 rounded-2xl border border-amber-100 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-amber-900 text-sm">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Pendekatan Pembelajaran (Usia 4–8 Tahun)</span>
            </div>
            <p className="text-amber-800">
              Aplikasi ini berfokus pada penguatan positif: jawaban yang tepat selalu diapresiasi dengan bintang dan suara ceria, sementara kesalahan ditanggapi dengan dorongan lembut tanpa pengurangan bintang atau rasa frustrasi.
            </p>
          </div>

          {/* Audio Engine */}
          <div className="p-3 bg-sky-50 rounded-2xl border border-sky-100 space-y-1">
            <span className="font-bold text-sky-900 block text-xs">Suara Pelafalan Bahasa Indonesia</span>
            <p className="text-sky-800">
              Menggunakan mesin Text-to-Speech bawaan perangkat Android / peramban web dengan bahasa Indonesia yang ramah, jelas, dan bertempo ramah anak.
            </p>
          </div>

          {/* Reset Stars with Parental Gate */}
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-800 block text-xs">Koleksi Bintang Anak</span>
                <span className="text-[11px] text-slate-500">Tersimpan di memori perangkat</span>
              </div>

              {!showResetConfirm ? (
                <button
                  type="button"
                  onClick={() => setShowResetConfirm(true)}
                  className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Bintang</span>
                </button>
              ) : null}
            </div>

            {showResetConfirm && (
              <div className="mt-3 p-3 bg-white rounded-xl border border-slate-300 space-y-2">
                <div className="flex items-center gap-1 text-slate-700 font-bold">
                  <Lock className="w-3.5 h-3.5 text-amber-600" />
                  <span>Kunci Orang Tua: Berapa 4 + 3?</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={mathAnswer}
                    onChange={(e) => setMathAnswer(e.target.value)}
                    placeholder="Jawaban"
                    className="w-24 px-3 py-1.5 border rounded-lg text-sm text-center font-bold"
                  />
                  <button
                    type="button"
                    onClick={handleConfirmReset}
                    className="px-3 py-1.5 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-lg text-xs cursor-pointer"
                  >
                    Hapus
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowResetConfirm(false);
                      setMathError(false);
                    }}
                    className="px-2 py-1.5 text-slate-500 hover:text-slate-700 text-xs cursor-pointer"
                  >
                    Batal
                  </button>
                </div>
                {mathError && (
                  <p className="text-[11px] text-rose-500 font-bold">
                    Jawaban salah. Fitur ini hanya untuk orang tua.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-5">
          <ChildButton
            id="btn-close-parent-modal"
            color="slate"
            size="md"
            onClick={() => {
              playPop();
              onClose();
            }}
            className="w-full text-center justify-center font-bold"
          >
            <span>Tutup & Kembali</span>
          </ChildButton>
        </div>
      </div>
    </div>
  );
};
