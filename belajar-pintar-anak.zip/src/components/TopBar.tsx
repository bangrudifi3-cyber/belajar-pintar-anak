import React from 'react';
import { ArrowLeft, Volume2, Star } from 'lucide-react';
import { playPop } from '../utils/sound';

interface TopBarProps {
  title: string;
  subtitle?: string;
  stars: number;
  onBack?: () => void;
  onSpeak?: () => void;
  bgClass?: string;
}

export const TopBar: React.FC<TopBarProps> = ({
  title,
  subtitle,
  stars,
  onBack,
  onSpeak,
  bgClass = 'bg-white/80 backdrop-blur-md',
}) => {
  return (
    <header className={`sticky top-0 z-20 px-4 py-3 border-b border-amber-100 flex items-center justify-between gap-2 shadow-xs ${bgClass}`}>
      {/* Tombol Kembali (Bila ada onBack) */}
      <div className="flex items-center gap-2">
        {onBack ? (
          <button
            id="topbar-back-button"
            type="button"
            onClick={() => {
              playPop();
              onBack();
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-2xl font-bold text-sm shadow-xs active:scale-95 transition-transform"
            aria-label="Kembali ke menu sebelumnya"
          >
            <ArrowLeft className="w-5 h-5 text-amber-800" />
            <span className="font-semibold">Kembali</span>
          </button>
        ) : (
          <div className="flex items-center gap-1 text-2xl">
            🎈
          </div>
        )}

        <div className="leading-tight">
          <h1 className="text-lg font-black text-slate-800 tracking-tight flex items-center gap-1.5">
            {title}
          </h1>
          {subtitle && (
            <p className="text-xs font-semibold text-slate-500">{subtitle}</p>
          )}
        </div>
      </div>

      {/* Bagian Kanan: Tombol Suara & Badge Bintang */}
      <div className="flex items-center gap-2">
        {onSpeak && (
          <button
            id="topbar-speak-button"
            type="button"
            onClick={onSpeak}
            className="w-10 h-10 flex items-center justify-center bg-sky-100 hover:bg-sky-200 text-sky-700 rounded-2xl shadow-xs active:scale-95 transition-transform"
            title="Dengarkan Suara"
            aria-label="Dengarkan Suara"
          >
            <Volume2 className="w-5 h-5 animate-pulse" />
          </button>
        )}

        {/* Bintang Anak */}
        <div
          id="topbar-star-counter"
          className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-100 to-yellow-200 border-2 border-amber-300 rounded-full shadow-xs"
        >
          <Star className="w-5 h-5 fill-amber-400 text-amber-500 animate-bounce" />
          <span className="font-black text-amber-900 text-base">{stars}</span>
        </div>
      </div>
    </header>
  );
};
